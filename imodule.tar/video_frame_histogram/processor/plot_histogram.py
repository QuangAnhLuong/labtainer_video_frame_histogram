import numpy as np
import matplotlib.pyplot as plt
import os

os.makedirs("histogram_images", exist_ok=True)

for file in sorted(os.listdir("histograms")):

    hist = np.load(f"histograms/{file}")

    plt.figure()

    plt.plot(hist)

    output = file.replace(".npy", ".png")

    plt.savefig(f"histogram_images/{output}")

    plt.close()

print("Done plotting histogram")
