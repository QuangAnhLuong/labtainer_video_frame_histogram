import cv2
import numpy as np
import os

os.makedirs("histograms", exist_ok=True)

for file in sorted(os.listdir("gray_frames")):

    img = cv2.imread(f"gray_frames/{file}", 0)

    hist = cv2.calcHist([img], [0], None, [256], [0,256])

    output = file.replace("gray", "hist").replace(".png", ".npy")

    np.save(f"histograms/{output}", hist)

print("Done computing histogram")
