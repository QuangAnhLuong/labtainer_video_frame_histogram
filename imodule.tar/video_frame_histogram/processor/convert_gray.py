import cv2
import os

os.makedirs("gray_frames", exist_ok=True)

for file in sorted(os.listdir("frames")):

    img = cv2.imread(f"frames/{file}")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    output = file.replace("frame", "gray")

    cv2.imwrite(f"gray_frames/{output}", gray)

print("Done converting grayscale")
