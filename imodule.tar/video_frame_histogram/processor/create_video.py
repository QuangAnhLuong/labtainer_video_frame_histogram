import cv2
import numpy as np

width = 640
height = 480

video = cv2.VideoWriter(
    "input_video.mp4",
    cv2.VideoWriter_fourcc(*'mp4v'),
    30,
    (width, height)
)

for i in range(300):

    frame = np.zeros((height, width, 3), dtype=np.uint8)

    color = (i % 255, (i*2) % 255, (i*3) % 255)

    frame[:] = color

    cv2.putText(
        frame,
        f"Frame {i}",
        (50, 240),
        cv2.FONT_HERSHEY_SIMPLEX,
        2,
        (255,255,255),
        3
    )

    video.write(frame)

video.release()

print("Video created")
