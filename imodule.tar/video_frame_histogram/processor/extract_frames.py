import cv2
import os

video = cv2.VideoCapture("input_video.mp4")

os.makedirs("frames", exist_ok=True)

count = 0

while True:
    ret, frame = video.read()

    if not ret:
        break

    filename = f"frames/frame_{count:04d}.png"

    cv2.imwrite(filename, frame)

    count += 1

video.release()

print("Done extracting frames")
