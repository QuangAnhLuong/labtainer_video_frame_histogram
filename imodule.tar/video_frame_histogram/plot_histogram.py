import os
import numpy as np
import matplotlib.pyplot as plt

INPUT_DIR = "histograms"
OUTPUT_DIR = "histogram_images"

os.makedirs(OUTPUT_DIR, exist_ok=True)

files = sorted(os.listdir(INPUT_DIR))

for file in files[:10]:

    if not file.endswith(".npy"):
        continue

    hist = np.load(os.path.join(INPUT_DIR, file))

    plt.figure()

    plt.plot(hist)

    plt.title(file)

    plt.xlabel("Gray Level")

    plt.ylabel("Frequency")

    out_name = file.replace(".npy", ".png")

    out_path = os.path.join(OUTPUT_DIR, out_name)

    plt.savefig(out_path)

    plt.close()

    print(f"[+] Saved {out_path}")

print("[+] Plot completed")
